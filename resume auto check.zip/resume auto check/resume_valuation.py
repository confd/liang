# importing all the required modules
import PyPDF2
import docx2txt
import pandas as pd 
import os
import time

valuation_result_list = list()

for root, dirs, files in os.walk('C:/Users/liang124625/Desktop/Mayank/resume auto check'):
    for filename in files:
        # creating an object 
        if filename[-3:] == 'pdf':
            resume = open(filename, 'rb')

            # creating a pdf reader object
            pdfReader = PyPDF2.PdfFileReader(resume)

            # get the text of pdf file
            pageObj = pdfReader.getPage(0)
            text = [w.upper() for w in pageObj.extractText().split()]
        elif filename[-4:] == 'docx':
            text = [w.upper() for w in docx2txt.process(filename).split()]
        else: continue
            

        # initialize the result recording list
        result = list()
        
        # info input
        result.append(time.strftime("%x"))
        loc = list(k[0] for k in enumerate(filename) if k[1]=='_')
        result.append(filename[loc[2]+1:loc[4]].replace('_', ' '))
        result.append(filename[loc[0]+1:loc[1]].replace('_', ' '))

        # Education check
        if any(w in text for w in ['DOCTOR', 'PHD', 'PH.D.']):
            result.append('PhD')  
        elif any(w in text for w in ['MBA', '(MBA)']):
            result.append('MBA')
        elif 'MASTER' in text and text[text.index('MASTER')+2] == 'BUSINESS':
            result.append('MBA')
        elif 'MASTER' in text and text[text.index('MASTER')+2] == 'ART':
            result.append('MA')
        elif any(w in text for w in ['MA', 'M.A.', 'M.A']):
            result.append('MA')
        elif 'MASTER' in text and text[text.index('MASTER')+2] == 'SCIENCE':
            result.append('MS')
        elif any(w in text for w in ['MS', 'M.S.', 'M.S', 'M.SC.', 'M.SC' ]):
            result.append('MS')
        elif any(w in text for w in ['MASTER', 'MASTERS,', 'MASTERS', 'MASTERÕS']):
            result.append('MS')
        elif 'BACHELOR' in text and text[text.index('BACHELOR')+2] == 'ART':
            result.append('BA')
        elif any(w in text for w in ['BA', 'B.A.', 'B.A', 'B.A.']):
            result.append('BA')
        elif 'BACHELOR' in text and text[text.index('BACHELOR')+2] == 'BUSINESS':
            result.append('BBA')            
        elif any(w in text for w in ['BBA', 'B.B.A.']):
            result.append('BBA')        
        elif any(w in text for w in ['BACHELOR', 'BACHELORS', 'BS', 'B.S.', 'B.SC.', 'B.SC', 'B.S', 'B.S.,', 'B.TECH', 'BACHELORÕ']):
            result.append('BS')
        else: result.append('N/A')

        # Analytics Experience check
        count = 0
        for word in text:
            if 'ANALY' in word:
                count += 1
        if count > 2:
            result.append('Y')
        else: result.append('N')

        # Financial Services Experience check  
        count = 0
        for word in text:
            if any(w in word for w in ['FINANC', 'BANK']):
                count += 1
        if count > 3:
            result.append('Y')
        else: result.append('N')

        # Model Development/Validation Experience check
        if any(w in text for w in ['MODEL', 'MODELING', 'MODELS', 'VALIDATION', 'VALIDATE', 'VALIDATED', 'VALIDATES']):
            result.append('Y')
        else: result.append('N')

        # Documentation/Technical Writting check 
        if any(w in text for w in ['REPORTING', 'REPORT', 'REPORTS', 'REPORTED']):
            result.append('Y')
        else: result.append('N')

        # CCAR/Basel Experience check
        if any(w in text for w in ['CCAR', 'BASEL']):
            result.append('Y')
        else: result.append('N')

        # CECL Experience check
        if 'CECL' in text:
            result.append('Y')
        else: result.append('N')

        # Marketing Analytics Experience
        count = 0
        for word in text:
            if 'MARKET' in word:
                count += 1
        if count > 2:
            result.append('Y')
        else: result.append('N')

        # Current PNC check
        if 'PNC' in text:
            result.append('Y')
        else: result.append('N')

        # Big Data check 
        if 'BIG' in text:
            if 'DATA' in text[text.index('BIG')+1]:
                result.append('Y')
        elif any(w in text for w in ['HADOOP', 'PIG', 'HDFS', 'HIVE', 'SPARK', 'HBASE', 'MAPREDUCE']):
            result.append('Y')
        else: result.append('N')

        # R check
        if 'R' in text:
            result.append('Y')
        else: result.append('N')

        # SAS check
        if 'SAS' in text:
            result.append('Y')
        else: result.append('N')

        # Python check
        if any(w in text for w in ['PYTHON', 'NUMPY', 'PANDAS']):
            result.append('Y')
        else: result.append('N')

        # SQL/Hadoop check
        if any(w in text for w in ['SQL', 'Hadoop']):
            result.append('Y')
        else: result.append('N')

        # Tableau check
        if 'TABLEAU' in text:
            result.append('Y')
        else: result.append('N')
            
        valuation_result_list.append(result)

        
# Output the result to EXCEL file  
indicator = ['Last Pulled On', 'Candidate Name', 'Source', 'Highest Education', 'Analytics Experience', 
             'Financial Services Experience', 'Model Development/Validation Experience', 
             'Documentation/Technical Writting Experience', 'CCAR/Basel Experience', 
             'CECL Experience', 'Marketing Analytic Experience', 'Current PNC', 'Big Data',
             'R', 'SAS', 'Python', 'SQL/Hadoop', 'Tableau']

valuation_result_df = pd.DataFrame(valuation_result_list, columns=indicator)
writer = pd.ExcelWriter('valuation.xlsx')
valuation_result_df.to_excel(writer, 'sheet1')
writer.save()