
# coding: utf-8

# In[58]:


import pandas as pd
true = pd.read_excel('real.xlsx').sort_values(by=['Candidate Name'])
python = pd.read_excel('valuation.xlsx').sort_values(by=['Candidate Name'])
indicator = list(true.columns.values)
indicator.remove('Last Pulled On')
indicator.remove('Candidate Name')
indicator.remove('Source')

accuracy = dict()
metric = dict()
for key in indicator:
    true_vlaue = true[key].values
    pred_value = python[key].values
    tmp = dict()
    YY, YN, NY, NN, Y, N = 0, 0, 0, 0, 0, 0
    for loc in range(len(true_vlaue)):
        if true_vlaue[loc] == 'Y':
            if pred_value[loc] == 'Y':
                YY += 1
            else: YN += 1
        elif true_vlaue[loc] == 'N':
            if pred_value[loc] == 'N':
                NN += 1
            else: NY += 1
        elif true_vlaue[loc] == pred_value[loc]:
            Y =+ 1
        else:
            N =+ 1
#     print(YN)
#     print(YN+NY)
    if YY+NN != 0:
        tmp['Actual_Y & Predcit_Y'] = str(round(YY/(YY+NN)*100,2)) + '%'
        tmp['Actual_N & Predcit_N'] = str(round(NN/(YY+NN)*100,2)) + '%'
    else:
        tmp['Actual_Y & Predcit_Y'], tmp['Actual_N & Predcit_N'] = 0, 0    
    if YN+NY != 0:
        tmp['Actual_Y & Predcit_N'] = str(round(YN/(YN+NY)*100,2)) + '%'
        tmp['Actual_N & Predcit_Y'] = str(round(NY/(YN+NY)*100,2)) + '%'
    else:
        tmp['Actual_Y & Predcit_N'], tmp['Actual_N & Predcit_Y'] = 0, 0
    accuracy_pcg = (YY+NN+Y) / (YY+YN+NN+NY+Y+N) * 100
    accuracy[key] = str(round(accuracy_pcg, 2)) + '%'
    metric[key] = tmp
del metric['Highest Education']


print(pd.DataFrame(accuracy, index=['% Match']).T)
print(pd.DataFrame(metric).T)

